
# Automobile Checklist • Streamlit

## Run locally
pip install -r requirements.txt
streamlit run streamlit_app.py

## Deploy (Streamlit Community Cloud)
- Push to GitHub
- New app → set main file to streamlit_app.py
